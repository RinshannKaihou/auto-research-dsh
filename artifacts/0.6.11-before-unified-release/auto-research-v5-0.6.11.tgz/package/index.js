import { StorageClient } from './ipc.js';
import { SessionAdapter } from './session-adapter.js';
import { ResearchDomain } from './domain.js';
import { registerResearchCommand } from './commands.js';
import { registerResearchTools } from './tools.js';
import { registerResearchEvents } from './events.js';

export const name = 'auto-research-v5';
export const inject = ['commands', 'tools', 'systemPrompt', 'llm', 'goals', 'agents', 'sessionController', 'jobs', 'sessionProjections', 'subagents'];
export const RPC_CHANNEL = '/research-v5';

class UnavailableStorage {
  constructor(error) { this.error = error; }
  request() { return Promise.reject(this.error); }
  close() {}
}

function agentFor(ctx, sessionId) {
  if (typeof sessionId !== 'string' || !sessionId) throw new Error('sessionId is required');
  const agent = ctx.agents.get(sessionId);
  if (!agent) throw new Error('The native session is not currently attached');
  return agent;
}

export function registerNativeSubagentGuard(ctx, domain) {
  return ctx.tools.guard(exec => {
    if (exec.name !== 'subagent' || !exec.agent) return undefined;
    if (domain.sessionRoles?.get(exec.agent.id) === 'specialist') return 'Read-only specialists cannot start another agent';
    if (!domain.managedRole(exec.agent)) return undefined;
    return 'Managed research executors must use research_delegate so specialist identity, lineage, usage, and exit state are recorded.';
  });
}

export function apply(ctx, config = {}) {
  let storage;
  try {
    storage = new StorageClient(config);
  } catch (error) {
    storage = new UnavailableStorage(error instanceof Error ? error : new Error(String(error)));
  }
  const adapter = new SessionAdapter(ctx);
  const domain = new ResearchDomain(ctx, storage, adapter, config);
  const disposers = [];

  disposers.push(ctx.systemPrompt.section({
    name: 'tool:research',
    order: 700,
    text: [
      'When this native session is associated with a research project, use research_* tools to preserve durable research structure.',
      'Main coordinates and dispatches; node_core owns full experiments. Specialists are read-only. Publications may be partial and do not imply scientific validation. Only node_core finishes work segments. A successor must declare its actual predecessors and inputs; report a failed handoff instead of declaring a false root. Never edit .research or issue SQL repairs; use research_verify_specialist or research_verify_task.',
      'Do not start autonomous research unless the user enabled it through /research auto.',
      'In manual mode, start a consolidation reviewer only when the user explicitly asks for consolidation or review.',
    ].join('\n'),
  }));
  disposers.push(registerResearchCommand(ctx, domain));
  disposers.push(...registerResearchTools(ctx, domain));
  disposers.push(registerNativeSubagentGuard(ctx, domain));
  disposers.push(registerResearchEvents(ctx, domain));

  ctx.inject(['connection', 'webServer'], scoped => {
    scoped.connection.rpc.handle(RPC_CHANNEL, async (endpoint, payload = {}) => {
      try {
        if (endpoint === 'capabilities') {
          const value = await storage.request('capabilities', {}, {}, `capabilities:${payload.sessionId ?? 'none'}`);
          return { ok: true, value };
        }
        const agent = agentFor(ctx, payload.sessionId);
        const id = payload.operationId ?? `${agent.id}:workbench:${Date.now()}`;
        if (endpoint === 'query' || endpoint === 'status') {
          return { ok: true, value: await domain.query(agent) };
        }
        if (endpoint === 'workbench.summary') return {ok:true,value:await domain.workbenchSummary(agent)};
        if (endpoint === 'workbench.page') return {ok:true,value:await domain.workbenchPage(agent, {
          collection:payload.collection,...(payload.cursor??{}),limit:payload.limit??20,node_id:payload.nodeId,kind:payload.kind,
        })};
        if (endpoint === 'knowledge.page') return {ok:true,value:await domain.knowledgePage(agent, {
          query:payload.query,kind:payload.kind,status:payload.status,node_id:payload.nodeId,
          knowledge_id:payload.knowledgeId,history:payload.history===true,
          ...(payload.cursor??{}),limit:payload.limit??20,
        })};
        if (endpoint === 'presentation.get') return {ok:true,value:await domain.presentationGet(agent)};
        if (endpoint === 'reference.entries') return {ok:true,value:await domain.referenceEntries(agent, {
          ref:payload.ref,...(payload.cursor??{}),limit:payload.limit??50,
        })};
        if (endpoint === 'reference.content') return {ok:true,value:await domain.referenceContent(agent, {
          ref:payload.ref,offset:payload.offset??0,limit:payload.limit??32768,
        })};
        if (endpoint === 'history.page') {
          return { ok: true, value: await domain.page(agent, payload.collection, payload.cursor ?? {}, payload.limit ?? 50) };
        }
        if (endpoint === 'usage.page') {
          return { ok: true, value: await domain.page(agent, 'usage', payload.cursor ?? {}, payload.limit ?? 50) };
        }
        if (endpoint === 'changes.page') {
          return { ok: true, value: await domain.page(agent, 'changes', payload.cursor ?? {}, payload.limit ?? 50) };
        }
        if (endpoint === 'reference.chunk') return {ok:true,value:await domain.lookup(agent,{ref:payload.ref,offset:payload.offset??0,limit:32768})};
        if (endpoint === 'reference.get') {
          return { ok: true, value: await domain.lookup(agent, { ref: payload.ref }) };
        }
        if (endpoint === 'guidance.status') return { ok: true, value: await domain.guidanceStatus(agent) };
        if (endpoint === 'guidance.register') return { ok: true, value: await domain.guidanceRegister(agent, payload.path, payload.version, id) };
        if (endpoint === 'context.preview') return { ok: true, value: await domain.contextPreview(agent) };
        if (endpoint === 'open') {
          return { ok: true, value: await domain.open(agent, {
            goal: payload.goal,
          }, id) };
        }
        if (endpoint === 'auto') return {
          ok: true,
          value: await domain.auto(agent, id),
        };
        if (endpoint === 'pause' || (endpoint === 'resume' && !payload.targetSessionId)) {
          return { ok: true, value: await domain.projectGoals(agent, endpoint, id) };
        }
        if (endpoint === 'resume') return { ok: true, value: await domain.resumeSession(agent, payload.targetSessionId, id) };
        if (endpoint === 'retry') return { ok: true, value: payload.taskId ? await domain.retryTask(agent, payload.taskId, id) : await domain.resumeSession(agent, payload.targetSessionId, id, { retry: true }) };
        if (endpoint === 'verify-task') return { ok: true, value: await domain.verifyTask(agent, payload.taskId, id) };
        if (endpoint === 'verify-close') return { ok: true, value: await domain.verifyClose(agent, payload.targetSessionId, id) };
        if (endpoint === 'verify-specialist') return { ok: true, value: await domain.verifySpecialist(agent, payload.taskId, id) };
        if (endpoint === 'verify-stop') return { ok: true, value: await domain.verifyStop(agent, id) };
        if (endpoint === 'focus') {
          return { ok: true, value: await domain.focus(agent, payload.nodeId ?? null, id) };
        }
        if (endpoint === 'stop') {
          return { ok: true, value: await domain.stopProject(agent, id) };
        }
        if (endpoint === 'branch') {
          return { ok: true, value: await domain.branch(agent, payload.nodeId, id) };
        }
        if (endpoint === 'discussion.open') return { ok: true, value: await domain.discuss(agent, payload.nodeId, id, payload.fresh === true) };
        if (endpoint === 'restore.preview') return { ok: true, value: await domain.restorePreview(agent, payload.snapshotId) };
        if (endpoint === 'restore.create') {
          if (!payload.previewId) throw new Error('Restore requires a preview ID');
          return { ok: true, value: await domain.restore(agent, payload.snapshotId, id, payload.previewId) };
        }
        if (endpoint === 'restore') {
          return { ok: true, value: await domain.restore(agent, payload.snapshotId, id) };
        }
        if (endpoint === 'detach') {
          return { ok: true, value: await domain.detach(agent, id) };
        }
        throw new Error(`Unknown research workbench operation: ${endpoint}`);
      } catch (error) {
        return {
          ok: false,
          error: {
            code: 'research/unavailable',
            message: error instanceof Error ? error.message : String(error),
            details: {},
          },
        };
      }
    }, { authority: 'trusted-host' });
  });

  return () => {
    for (const dispose of disposers.reverse()) dispose();
    storage.close();
  };
}
